This ecommerce project consist of 3modules:
1) Admin
2) Customer
3) Delivery Boy

------------------------------------------------------------------------

Steps to run:
1) Download the zipfile and extract files in htdocs.
2) Open phpmyadmin and create db name 'ecom'.
3) Import db of ecom from ecom.sql


========================================================================

user login:
email: admin@gmail.com
pass: admin

-----------------------------------------------------------------------
admin login:

name: admin
pass: admin

add delivery boy and do it yourself

+=======================================================================
Copyright @ APPS 2023