

        <?php

                        include("header.php");
                        

        ?>

        <?php

                        include("sector.php");
                        

        ?>
</section>
<!-- home section ends -->

<div class="up">
            <?php
                include("sidebar.php");
            ?>  
        </div>
    <!-- Categories Panel-->
    <div class="abcd" id="productts">
        <h2>
            <a href="ourproduct.php" style="color:#4fbfa8;" >Our Latest Products</a>
        </h2>
      
    </div>
        