<?php
echo "<h1> Payment Failed";

?>
<a href="http://localhost/ecom/index.php">Goto Homepage</a>