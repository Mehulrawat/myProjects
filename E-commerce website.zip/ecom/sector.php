



    </div>
    <section class="home" id="home">
<div id="row1" class="row1">
    
    <div class="col-21">
        <img src="images/main.png" alt="">
        <div class="content">
            <h1>Living made easy <BR> Appliances for your ease </h1>
                <a href="ourproduct.php" class="btn1">Explore Now</a>
        </div>
        
    </div>

 </div> 