
<?php require('header.php') ?>
<?php include('sidebar.php') ?>

<div class="small-container">

    <div class="row">
            <div class="abcd" style="margin-top:80px;">
                
                <h1>Thank you for the purchase</h1>
                
            
            </div>
        

    </div>
</div>
<div class="small-container" >
    <a href="index.php" class="btn">Continue Shopping &#8594;</a>
    
</div>


<?php require('footer.php'); ?>