namespace PostManagement.Domain.Enums;

public enum UserRoleName
{
    User = 0,
    Admin = 1,
    SuperAdmin = 2
}
