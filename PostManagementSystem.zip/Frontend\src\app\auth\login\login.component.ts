import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  errorMessage = '';
  isSubmitting = false;

  form = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
  });

  returnUrl: string = '/';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/';
  }

  submit() {
    if (this.form.invalid) return;

    const { username, password } = this.form.value;
    this.errorMessage = '';
    this.isSubmitting = true;

    this.auth.login(username!, password!).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.router.navigateByUrl(this.returnUrl);
      },
      error: err => {
        this.isSubmitting = false;
        this.errorMessage =
          err?.error?.message || 'Login failed. Please check your credentials.';
      }
    });
  }
}
