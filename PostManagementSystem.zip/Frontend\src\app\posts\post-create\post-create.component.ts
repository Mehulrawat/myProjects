import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PostService } from '../../core/services/post.service';
import { PostCategory } from '../../core/models/post.model';

@Component({
  selector: 'app-post-create',
  templateUrl: './post-create.component.html'
})
export class PostCreateComponent {
  isSubmitting = false;
  errorMessage = '';
  successMessage = '';

  postCategory = PostCategory;
  categoryKeys = Object.keys(PostCategory).filter(k => !isNaN(Number(PostCategory[k as any])));

  form = this.fb.group({
    title: ['', Validators.required],
    content: ['', Validators.required],
    category: [PostCategory.Issue, Validators.required]
  });

  constructor(
    private fb: FormBuilder,
    private postService: PostService,
    private router: Router
  ) {}

  submit() {
    if (this.form.invalid) return;

    const { title, content, category } = this.form.value;
    this.isSubmitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.postService
      .createPost(title!, content!, Number(category))
      .subscribe({
        next: () => {
          this.isSubmitting = false;
          this.successMessage = 'Draft post created successfully.';
          setTimeout(() => this.router.navigate(['/posts/my']), 800);
        },
        error: () => {
          this.isSubmitting = false;
          this.errorMessage = 'Failed to create post.';
        }
      });
  }
}
