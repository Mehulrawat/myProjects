using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PostManagement.Application.Contracts.Comments;
using PostManagement.Application.Interfaces;
using PostManagement.Application.Interfaces.Repositories;
using PostManagement.Domain.Entities;

namespace PostManagement.Application.Services;

public class CommentService
{
    private readonly ICommentRepository _commentRepository;
    private readonly IUserRepository _userRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CommentService(ICommentRepository commentRepository, IUserRepository userRepository, IUnitOfWork unitOfWork)
    {
        _commentRepository = commentRepository;
        _userRepository = userRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task AddCommentAsync(Guid postId, Guid userId, string content, Guid? parentCommentId)
    {
        var user = await _userRepository.GetByIdAsync(userId)
                   ?? throw new InvalidOperationException("User not found.");

        var comment = new Comment
        {
            Id = Guid.NewGuid(),
            PostId = postId,
            ParentCommentId = parentCommentId,
            Content = content,
            CreatedByUserId = user.Id,
            CreatedAt = DateTime.UtcNow
        };

        await _commentRepository.AddAsync(comment);
        await _unitOfWork.SaveChangesAsync();
    }

    public async Task<List<CommentResponse>> GetCommentsForPostAsync(Guid postId)
    {
        var comments = await _commentRepository.GetByPostIdAsync(postId);

        var responseLookup = comments.ToDictionary(
            c => c.Id,
            c => new CommentResponse
            {
                Id = c.Id,
                Content = c.Content,
                CreatedAt = c.CreatedAt,
                CreatedBy = c.CreatedByUser.Username,
                ParentCommentId = c.ParentCommentId
            });

        // Build tree
        List<CommentResponse> roots = new();
        foreach (var c in comments)
        {
            var resp = responseLookup[c.Id];
            if (c.ParentCommentId.HasValue && responseLookup.ContainsKey(c.ParentCommentId.Value))
            {
                responseLookup[c.ParentCommentId.Value].Replies.Add(resp);
            }
            else
            {
                roots.Add(resp);
            }
        }

        return roots;
    }
}
