import { Component, OnInit } from '@angular/core';
import { Post, PostStatus } from '../../core/models/post.model';
import { PostService } from '../../core/services/post.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html'
})
export class AdminDashboardComponent implements OnInit {
  posts: Post[] = [];
  isLoading = false;
  errorMessage = '';

  postStatus = PostStatus;

  constructor(private postService: PostService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.isLoading = true;
    this.postService.getAllPosts().subscribe({
      next: posts => {
        this.posts = posts;
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load posts.';
        this.isLoading = false;
      }
    });
  }

  statusLabel(status: PostStatus) {
    return PostStatus[status];
  }

  approve(post: Post) {
    this.postService.approvePost(post.id).subscribe({
      next: () => this.load(),
      error: () => (this.errorMessage = 'Failed to approve post.')
    });
  }

  reject(post: Post) {
    this.postService.rejectPost(post.id).subscribe({
      next: () => this.load(),
      error: () => (this.errorMessage = 'Failed to reject post.')
    });
  }

  close(post: Post) {
    this.postService.closePost(post.id).subscribe({
      next: () => this.load(),
      error: () => (this.errorMessage = 'Failed to close post.')
    });
  }
}
